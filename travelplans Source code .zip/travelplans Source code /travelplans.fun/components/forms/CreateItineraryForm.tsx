import React from 'react';

// This component is not used in the application.
// It has been populated with a minimal functional component
// to prevent potential build errors caused by an empty .tsx file.
// It is recommended to remove this file from the project if possible.
const CreateItineraryForm: React.FC = () => {
  return null;
};

export default CreateItineraryForm;
